-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 01 Okt 2022 pada 05.59
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `psikotes_depresi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `kategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `email`, `username`, `password`, `kategori`) VALUES
(1, 'admin@psikolog.com', 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `konsultasi`
--

CREATE TABLE `konsultasi` (
  `Idpasien` int(12) NOT NULL,
  `Username` varchar(32) NOT NULL,
  `Namapasien` varchar(255) NOT NULL,
  `Email` varchar(32) NOT NULL,
  `Jeniskelamin` varchar(32) NOT NULL,
  `Tgllahir` date NOT NULL,
  `Idpenyakit` varchar(12) NOT NULL,
  `Nilai_diagnosa` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `konsultasi`
--

INSERT INTO `konsultasi` (`Idpasien`, `Username`, `Namapasien`, `Email`, `Jeniskelamin`, `Tgllahir`, `Idpenyakit`, `Nilai_diagnosa`) VALUES
(1, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.629227864'),
(2, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.629227864'),
(3, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', '', ''),
(4, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', '', ''),
(5, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.914816418'),
(6, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.76341504'),
(7, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', '', ''),
(8, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0.1426'),
(9, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0.49234416'),
(10, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.943151334'),
(11, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.629227864'),
(12, 'andizulfikar', '', 'andizul@gmail.com', 'Laki-Laki', '1989-09-11', 'Major', '0.60700192'),
(13, 'andizul', 'Andi Zulfikar', 'andizulikar@gmail.com', 'Laki-Laki', '1988-09-10', 'Stress', '0.21565048'),
(14, 'yuli08', 'Yuli Yuarti', 'indahpadawaktunya08@gmail.com', 'Perempuan', '1998-09-10', 'Major', '0.798406653'),
(15, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.985229168'),
(16, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.881718116'),
(17, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.629227864'),
(18, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0'),
(19, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0'),
(20, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0'),
(21, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0.411043846'),
(22, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.704903704'),
(23, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.708327096'),
(24, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.708327096'),
(25, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.701276092'),
(26, '', 'Johana Mahulae', 'johanamahulae@gmail.com', 'Laki-Laki', '0000-00-00', 'Major', '0.690893489'),
(27, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Major', '0.995727015'),
(28, 'Fachrel08', 'fachrel marpaung', 'fachrel@gmail.com', ' Laki-Laki', '1989-10-11', 'Stress', '0.282');

-- --------------------------------------------------------

--
-- Struktur dari tabel `soal`
--

CREATE TABLE `soal` (
  `Soalid` int(11) NOT NULL,
  `Soal` text NOT NULL,
  `Nilai_H1` varchar(12) NOT NULL,
  `Nilai_H2` varchar(12) NOT NULL,
  `Moderate` int(11) NOT NULL,
  `Major` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `soal`
--

INSERT INTO `soal` (`Soalid`, `Soal`, `Nilai_H1`, `Nilai_H2`, `Moderate`, `Major`) VALUES
(1, 'Kehilangan minat dan kegembiraan', '0.713', '0.856', 0, 0),
(2, 'Gagasan tentang rasa bersalah dan tidak berguna', '0.856', '0.569', 1, 1),
(3, 'Mood depresif', '0', '0.569', 0, 1),
(4, 'Mengalami kesulitan untuk fokus dan\r\nberkonsetrasi', '0.282', '0.426', 1, 1),
(5, 'harga diri dan kepercayaan diri yang kurang', '0.426', '0', 0, 0),
(6, 'Perbuatan yang membahayakan dirinya sendiri atau bunuh diri', '0', '0.569', 0, 0),
(7, 'Pandangan masa depan yang suram dan pesimistis ', '0.282', '0.569', 1, 1),
(8, 'Berkurangnya energi yang menuju keadaan mudah lelah dan menurunya aktivitas', '0.282', '0.426', 1, 1),
(9, 'Tidur tergangguTidur terganggu', '0', '0.426', 0, 0),
(10, 'Mengalami waham dan halusinasi', '0', '0.426', 0, 0),
(11, 'Lamanya gejala tersebut berlangsung sekurang - kurangnya 2 minggu', '0.282', '0.569', 1, 1),
(12, 'Merasa sedih dan kesepian ', '0.426', '0.713', 1, 1),
(13, 'Mengatasi kesulitan untuk meneruskan kegiatan sosial, pekerjaan atau urusan rumah tangga', '0.569', '', 1, 0),
(14, 'Nafsu makan tidak menentu, terkadang naik, kadang menurun', '0.282', '0.713', 1, 1),
(15, 'Hanya sedikit kesulitan dalam pekerjaan dan kegiatan sosial yang biasa dilakukan', '0', '0.713', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `Id` int(11) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Namapasien` varchar(255) NOT NULL,
  `Username` varchar(32) NOT NULL,
  `Passwd` varchar(32) NOT NULL,
  `Jkel` varchar(32) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`Id`, `Email`, `Namapasien`, `Username`, `Passwd`, `Jkel`, `tgl_lahir`, `alamat`) VALUES
(1, 'ferdinand08@gmail.com', '', 'ferdinand30', 'ferdinand', ' Laki-Laki', '1994-11-11', 'Jln Katamso'),
(2, 'Herryherawan@gmail.com', '', 'Herryherawan08', 'herryherawan', ' Laki-Laki', '1988-08-07', 'Jalan Punak'),
(3, 'Kiranadewi1877@gmail.com', '', 'Kiranadewi1877', 'kiranadewi1877', ' Laki-Laki', '1877-06-09', 'Jln Yos sudarso'),
(4, 'fachrel@gmail.com', 'fachrel marpaung', 'Fachrel08', 'fachrel08', ' Laki-Laki', '1989-10-11', 'Jalan Ayahanda'),
(5, 'andizul@gmail.com', 'Andi Zulfikar', 'andizulfikar', 'Lol123!@#', ' Laki-Laki', '1989-09-11', 'Jalan bromo'),
(6, 'andizulikar@gmail.com', 'Andi Zulfikar', 'andizul', 'Lol123!@#', 'Laki-Laki', '1988-09-10', 'Jalan jalan'),
(7, 'indahpadawaktunya08@gmail.com', 'Yuli Yuarti', 'yuli08', 'kampret08', 'Perempuan', '1998-09-10', 'Jalan jalan dong'),
(8, 'contoh21@gmail.com', 'andi zul', 'andizul80', 'Lol123!@#', 'Laki-Laki', '1998-09-19', 'Jalan jalan'),
(9, 'johanamahulae@gmail.com', 'Johana Mahulae', '', '', 'Laki-Laki', '0000-00-00', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  ADD PRIMARY KEY (`Idpasien`);

--
-- Indeks untuk tabel `soal`
--
ALTER TABLE `soal`
  ADD PRIMARY KEY (`Soalid`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `konsultasi`
--
ALTER TABLE `konsultasi`
  MODIFY `Idpasien` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `soal`
--
ALTER TABLE `soal`
  MODIFY `Soalid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
